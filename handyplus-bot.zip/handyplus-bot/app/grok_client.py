from __future__ import annotations

import os

import httpx

XAI_URL = "https://api.x.ai/v1/chat/completions"


class GrokClient:
    def __init__(self) -> None:
        self.api_key = os.environ["XAI_API_KEY"]
        self.model = os.getenv("XAI_MODEL", "grok-4-fast-non-reasoning")

    def complete(self, system: str, user: str, temperature: float = 0.2) -> str:
        payload = {
            "model": self.model,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        with httpx.Client(timeout=60) as client:
            r = client.post(XAI_URL, json=payload, headers=headers)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
