from __future__ import annotations

import json
from typing import Any

EXTRACT_INSTRUCTIONS = """
חלץ מהודעת הלקוח JSON בלבד, בלי טקסט נוסף.
סכימה:
{
  "job_id": null | אחד מהמזהים המותרים,
  "wall": null | "concrete" | "plasterboard" | "unknown",
  "has_elevator": null | true | false,
  "tv_inches": null | number,
  "wants_arm": null | true | false,
  "photos_mentioned": false,
  "escalate": false,
  "escalate_reason": null | string,
  "missing": [string]
}

job_id מותרים בלבד:
tv_upto_55, tv_over_55, shelf, mirror_or_picture, curtain_track,
faucet, siphon, leak_simple, silicone,
socket_or_switch, light_fixture, ceiling_fan,
dresser, table, bed, wardrobe_2_3, door_adjust, patch_paint

אם טלוויזיה מעל 55 -> tv_over_55, אחרת עד 55 כולל -> tv_upto_55.
אם מוזכר לוח חשמל / נקודה חדשה / חציבה / גז / דוד / גובה מסוכן: escalate=true.
אם לא ברור סוג העבודה: job_id=null והוסף ל-missing.
""".strip()


def parse_extract(raw: str) -> dict[str, Any]:
    text = raw.strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text.replace("json", "", 1).strip()
    data = json.loads(text)
    allowed = {
        "tv_upto_55",
        "tv_over_55",
        "shelf",
        "mirror_or_picture",
        "curtain_track",
        "faucet",
        "siphon",
        "leak_simple",
        "silicone",
        "socket_or_switch",
        "light_fixture",
        "ceiling_fan",
        "dresser",
        "table",
        "bed",
        "wardrobe_2_3",
        "door_adjust",
        "patch_paint",
    }
    job = data.get("job_id")
    if job not in allowed:
        data["job_id"] = None
    return data
