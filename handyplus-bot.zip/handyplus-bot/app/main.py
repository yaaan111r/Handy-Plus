from __future__ import annotations

import os
from functools import lru_cache

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from app.engine import QuoteBot

app = FastAPI(title="Handy Plus Quote Bot")


@lru_cache
def bot() -> QuoteBot:
    return QuoteBot()


class SimulateIn(BaseModel):
    from_: str | None = None
    text: str

    model_config = {"populate_by_name": True}


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/simulate")
def simulate(body: SimulateIn) -> dict[str, str]:
    reply = bot().handle(body.text)
    return {"reply": reply}


@app.post("/twilio/whatsapp")
async def twilio_whatsapp(
    request: Request,
    From: str = Form(default=""),
    Body: str = Form(default=""),
) -> PlainTextResponse:
    token = os.getenv("TWILIO_AUTH_TOKEN")
    if token:
        from twilio.request_validator import RequestValidator

        validator = RequestValidator(token)
        form = dict((await request.form()).items())
        url = str(request.url)
        sig = request.headers.get("X-Twilio-Signature", "")
        if not validator.validate(url, form, sig):
            raise HTTPException(status_code=403, detail="bad twilio signature")

    text = Body.strip() or "שלום"
    reply = bot().handle(text)
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>{_xml_escape(reply)}</Message>
</Response>"""
    return PlainTextResponse(xml, media_type="application/xml")


def _xml_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
