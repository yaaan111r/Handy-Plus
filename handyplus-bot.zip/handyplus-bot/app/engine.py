from __future__ import annotations

import json

from app.extract import EXTRACT_INSTRUCTIONS, parse_extract
from app.grok_client import GrokClient
from app.pricing import catalog_for_prompt, load_pricing
from app.quote import compute_quote
from app.rules import SYSTEM_RULES


class QuoteBot:
    def __init__(self) -> None:
        self.pricing = load_pricing()
        self.grok = GrokClient()

    def handle(self, customer_text: str) -> str:
        extract_user = (
            EXTRACT_INSTRUCTIONS
            + "\n\nקטלוג מזהים:\n"
            + catalog_for_prompt(self.pricing)
            + "\n\nהודעת לקוח:\n"
            + customer_text
        )
        raw = self.grok.complete(
            system="אתה מחלץ JSON בלבד. בלי הסברים.",
            user=extract_user,
            temperature=0,
        )
        try:
            extracted = parse_extract(raw)
        except Exception:
            extracted = {
                "job_id": None,
                "escalate": False,
                "missing": ["סוג העבודה"],
            }

        quote = compute_quote(extracted, self.pricing)
        reply_user = (
            "הודעת לקוח:\n"
            f"{customer_text}\n\n"
            "נתונים שחולצו:\n"
            f"{json.dumps(extracted, ensure_ascii=False)}\n\n"
            "תוצאת מחירון (רק זה מותר לציטוט כמחיר):\n"
            f"{json.dumps(quote, ensure_ascii=False)}"
        )
        return self.grok.complete(system=SYSTEM_RULES, user=reply_user, temperature=0.2)
