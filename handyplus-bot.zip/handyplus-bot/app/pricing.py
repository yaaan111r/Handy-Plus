from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

PRICING_PATH = Path(__file__).resolve().parents[1] / "data" / "pricing.yaml"


def load_pricing() -> dict[str, Any]:
    with PRICING_PATH.open(encoding="utf-8") as f:
        return yaml.safe_load(f)


def catalog_for_prompt(data: dict[str, Any]) -> str:
    lines = [
        f"מטבע: {data['currency']}",
        f"כולל מע״מ: {data['vat_included']}",
        f"תוקף הצעה: {data['quote_valid_days']} ימים",
        f"מינימום ביקור: {data['minimum_visit']}",
        "",
        "עבודות:",
    ]
    for cat in data["categories"].values():
        lines.append(f"- {cat['label']}")
        for job in cat["jobs"].values():
            lines.append(f"  • {job['label']}: {job['base']} ₪")
    lines.append("תוספות:")
    for s in data["surcharges"].values():
        lines.append(f"  • {s['label']}: +{s['amount']} ₪")
    lines.append("לא מתמחרים אוטומטית:")
    for item in data["never_auto_quote"]:
        lines.append(f"  • {item}")
    return "\n".join(lines)
