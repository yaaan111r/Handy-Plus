from __future__ import annotations

from typing import Any


def compute_quote(extracted: dict[str, Any], pricing: dict[str, Any]) -> dict[str, Any]:
    if extracted.get("escalate"):
        return {
            "status": "escalate",
            "reason": extracted.get("escalate_reason") or "נדרשת בדיקה אנושית",
            "total": None,
        }

    job_id = extracted.get("job_id")
    if not job_id:
        return {
            "status": "need_more_info",
            "missing": extracted.get("missing") or ["סוג העבודה"],
            "total": None,
        }

    job = None
    label = None
    for cat in pricing["categories"].values():
        if job_id in cat["jobs"]:
            job = cat["jobs"][job_id]
            label = job["label"]
            break
    if not job:
        return {"status": "need_more_info", "missing": ["סוג העבודה"], "total": None}

    total = int(job["base"])
    extras = []
    sur = pricing["surcharges"]

    if extracted.get("wall") == "plasterboard":
        total += sur["plasterboard"]["amount"]
        extras.append(sur["plasterboard"]["label"])
    if extracted.get("has_elevator") is False:
        total += sur["no_elevator"]["amount"]
        extras.append(sur["no_elevator"]["label"])
    if extracted.get("wants_arm") and job_id.startswith("tv_"):
        total += sur["arm_bracket"]["amount"]
        extras.append(sur["arm_bracket"]["label"])

    total = max(total, int(pricing["minimum_visit"]))

    missing = []
    if job_id.startswith("tv_") and extracted.get("wall") in (None, "unknown"):
        missing.append("סוג הקיר (בטון / גבס)")
    if job_id.startswith("tv_") and not extracted.get("tv_inches"):
        missing.append("גודל המסך באינץ'")

    if missing:
        return {"status": "need_more_info", "missing": missing, "total": None, "job_label": label}

    return {
        "status": "ready",
        "job_label": label,
        "total": total,
        "extras": extras,
        "vat_included": pricing["vat_included"],
        "quote_valid_days": pricing["quote_valid_days"],
        "currency": pricing["currency"],
        "note": pricing["travel_note"],
    }
