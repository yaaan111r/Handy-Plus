# הנדי פלוס — בוט הצעות מחיר (Grok API)

תוכנה קטנה: הלקוח כותב בוואטסאפ → השרת מחלץ פרטים → **המחיר מחושב רק מהמחירון** → Grok מנסח תשובה בעברית לפי חוקים קשיחים.

Grok לא ממציא מחירים. אם חסר מידע — הוא שואל, לא מתמחר.

## הרצה מקומית

```bash
cd handyplus-bot
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# שימו XAI_API_KEY ב-.env
uvicorn app.main:app --reload --port 8080
```

בדיקה בלי וואטסאפ:

```bash
curl -X POST http://127.0.0.1:8080/simulate \
  -H 'Content-Type: application/json' \
  -d '{"from":"0550000000","text":"צריך לתלות טלוויזיה 55 אינץ על קיר בטון"}'
```

## חיבור לטוויליו (אופציונלי)

ב-Twilio Console → WhatsApp sandbox / sender → Webhook:
`https://YOUR-DOMAIN/twilio/whatsapp`

משתני סביבה: `TWILIO_AUTH_TOKEN` לאימות חתימה.

## פריסה
Railway / Render / Fly.io — שירות עם URL ציבורי HTTPS.
לא ניתן להריץ את זה מתוך אפליקציית Grok; רק לקרוא ל-API של Grok מהשרת הזה.
